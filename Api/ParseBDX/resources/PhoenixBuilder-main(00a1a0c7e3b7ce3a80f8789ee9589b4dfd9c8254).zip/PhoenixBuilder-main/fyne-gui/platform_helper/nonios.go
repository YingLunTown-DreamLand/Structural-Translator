// +build !ios

package platform_helper

func DoNetworkRequest() {
}

func RunBackground() {
}

func StopBackground() {
}