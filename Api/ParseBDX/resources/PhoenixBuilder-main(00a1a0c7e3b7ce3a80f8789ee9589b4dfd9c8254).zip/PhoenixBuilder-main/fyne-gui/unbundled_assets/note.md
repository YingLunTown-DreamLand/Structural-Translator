The requirements of runme_to_bundle.sh can be found in https://github.com/crvdgc/Consolas-with-Yahei

Not storaged by this repository for its size.

no liscence provided
