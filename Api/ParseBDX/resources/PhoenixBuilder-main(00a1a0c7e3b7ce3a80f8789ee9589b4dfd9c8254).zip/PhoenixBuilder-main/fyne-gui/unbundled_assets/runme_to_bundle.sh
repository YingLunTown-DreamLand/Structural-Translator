fyne bundle --package assets --prefix Resource Icon.png > ../gui/assets/bundleIcon.go
fyne bundle --package assets --name ResourceRegularFont Consolas_with_Yahei_Regular.ttf > ../gui/assets/bundleRegularFont.go
fyne bundle --package assets --name ResourceBoldFont Consolas_with_Yahei_Bold.ttf > ../gui/assets/bundleBoldFont.go