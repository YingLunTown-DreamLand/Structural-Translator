// +build fyne_gui

package session

const DefaultFBVersion = "1.5.1"
const DefaultFBHash = ""
const DefaultFBCodeName = "Phoenix"
