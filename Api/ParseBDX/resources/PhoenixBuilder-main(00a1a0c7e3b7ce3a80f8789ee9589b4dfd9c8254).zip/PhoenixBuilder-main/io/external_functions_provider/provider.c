#include <stdlib.h>

void phoenixbuilder_output(){}
void phoenixbuilder_worldchat_output(){}
void phoenixbuilder_send_silent_command(){}
void phoenixbuilder_send_ws_command(){}
void phoenixbuilder_send_command(){}
void phoenixbuilder_send_chat(){}
void phoenixbuilder_show_title(){}
void phoenixbuilder_get_block(){}
void phoenixbuilder_get_block_data(){}
void phoenixbuilder_get_ranged_blocks(){}
void phoenixbuilder_update_command_block(){}