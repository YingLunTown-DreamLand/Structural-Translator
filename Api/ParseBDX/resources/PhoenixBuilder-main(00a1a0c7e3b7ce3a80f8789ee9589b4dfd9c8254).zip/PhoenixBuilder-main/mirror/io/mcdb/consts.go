package mcdb

var WorldDimension = 0
var GameVersion = "1.18.30"
var NetworkVersion = 503
