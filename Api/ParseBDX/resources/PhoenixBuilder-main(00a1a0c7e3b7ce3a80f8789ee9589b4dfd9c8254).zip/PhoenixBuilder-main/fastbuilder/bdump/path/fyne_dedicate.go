// +build fyne_gui

package path

var CreateFile func(string) (FileWriter,error)
