// +build fyne_gui

package I18n

func Init() {
	I18nDict = I18nDict_zh_CN
}