#pragma once
#include "_cgo_export.h"

char *resolveGoStringPtr(GoString *str);

