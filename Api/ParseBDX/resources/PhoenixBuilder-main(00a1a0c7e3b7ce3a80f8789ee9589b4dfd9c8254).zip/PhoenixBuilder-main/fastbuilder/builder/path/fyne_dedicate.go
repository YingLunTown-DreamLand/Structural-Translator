// +build fyne_gui

package path

var ReadFile func(string) (FileReader,error)
