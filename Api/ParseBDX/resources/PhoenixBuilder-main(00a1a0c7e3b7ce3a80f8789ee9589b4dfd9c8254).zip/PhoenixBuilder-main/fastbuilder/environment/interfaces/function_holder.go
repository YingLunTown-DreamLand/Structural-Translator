package interfaces

type FunctionHolder interface {
	Process(string) bool
}