package types

type Entity string
