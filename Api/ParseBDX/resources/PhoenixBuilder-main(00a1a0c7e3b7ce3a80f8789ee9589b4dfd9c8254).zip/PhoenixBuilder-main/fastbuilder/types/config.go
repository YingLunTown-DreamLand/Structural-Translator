package types


type Config struct {
	Address, Pattern string
}
