package types

var ForwardedBrokSender chan string