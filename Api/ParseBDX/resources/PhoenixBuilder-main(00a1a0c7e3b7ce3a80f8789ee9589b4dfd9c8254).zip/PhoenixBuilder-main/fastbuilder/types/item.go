package types

type Item struct {
	Name string
	NetworkID uint16
	MaxDamage uint16
}