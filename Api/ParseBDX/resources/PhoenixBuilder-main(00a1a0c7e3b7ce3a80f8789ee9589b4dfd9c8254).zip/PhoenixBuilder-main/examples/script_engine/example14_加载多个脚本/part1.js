engine.message("hello from part1.js");

module.exports="this is a value in part1";