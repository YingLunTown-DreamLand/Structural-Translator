const part1=require("part1.js");
const part2=require("part2.js");
part2.doit(part1);
console.log("%s from part2.get().",JSON.stringify(part2.get()));
