package resource

// DefaultSkinResourcePatch holds the skin resource patch assigned to a player when they wear a custom skin.
const DefaultSkinResourcePatch = `{
   "geometry" : {
      "default" : "geometry.humanoid.custom"
   }
}
`

// DefaultSkinGeometry holds the skin geometry assigned to a player when they wear a custom skin.
const DefaultSkinGeometry = `
{
   "format_version" : "1.12.0",
   "minecraft:geometry" : [
      {
         "bones" : [
            {
               "name" : "body",
               "parent" : "waist",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "name" : "waist",
               "pivot" : [ 0.0, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -5.0, 8.0, 3.0 ],
                     "size" : [ 10, 16, 1 ],
                     "uv" : [ 0, 0 ]
                  }
               ],
               "name" : "cape",
               "parent" : "body",
               "pivot" : [ 0.0, 24.0, 3.0 ],
               "rotation" : [ 0.0, 180.0, 0.0 ]
            }
         ],
         "description" : {
            "identifier" : "geometry.cape",
            "texture_height" : 32,
            "texture_width" : 64
         }
      },
      {
         "bones" : [
            {
               "name" : "root",
               "pivot" : [ 0.0, 0.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -4.0, 12.0, -2.0 ],
                     "size" : [ 8, 12, 4 ],
                     "uv" : [ 16, 16 ]
                  }
               ],
               "name" : "body",
               "parent" : "waist",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "name" : "waist",
               "parent" : "root",
               "pivot" : [ 0.0, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -4.0, 24.0, -4.0 ],
                     "size" : [ 8, 8, 8 ],
                     "uv" : [ 0, 0 ]
                  }
               ],
               "name" : "head",
               "parent" : "body",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "name" : "cape",
               "parent" : "body",
               "pivot" : [ 0.0, 24, 3.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.50,
                     "origin" : [ -4.0, 24.0, -4.0 ],
                     "size" : [ 8, 8, 8 ],
                     "uv" : [ 32, 0 ]
                  }
               ],
               "name" : "hat",
               "parent" : "head",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ 4.0, 12.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 32, 48 ]
                  }
               ],
               "name" : "leftArm",
               "parent" : "body",
               "pivot" : [ 5.0, 22.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ 4.0, 12.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 48, 48 ]
                  }
               ],
               "name" : "leftSleeve",
               "parent" : "leftArm",
               "pivot" : [ 5.0, 22.0, 0.0 ]
            },
            {
               "name" : "leftItem",
               "parent" : "leftArm",
               "pivot" : [ 6.0, 15.0, 1.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -8.0, 12.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 40, 16 ]
                  }
               ],
               "name" : "rightArm",
               "parent" : "body",
               "pivot" : [ -5.0, 22.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -8.0, 12.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 40, 32 ]
                  }
               ],
               "name" : "rightSleeve",
               "parent" : "rightArm",
               "pivot" : [ -5.0, 22.0, 0.0 ]
            },
            {
               "locators" : {
                  "lead_hold" : [ -6, 15, 1 ]
               },
               "name" : "rightItem",
               "parent" : "rightArm",
               "pivot" : [ -6, 15, 1 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -0.10, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 16, 48 ]
                  }
               ],
               "name" : "leftLeg",
               "parent" : "root",
               "pivot" : [ 1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -0.10, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 48 ]
                  }
               ],
               "name" : "leftPants",
               "parent" : "leftLeg",
               "pivot" : [ 1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -3.90, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 16 ]
                  }
               ],
               "name" : "rightLeg",
               "parent" : "root",
               "pivot" : [ -1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -3.90, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 32 ]
                  }
               ],
               "name" : "rightPants",
               "parent" : "rightLeg",
               "pivot" : [ -1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -4.0, 12.0, -2.0 ],
                     "size" : [ 8, 12, 4 ],
                     "uv" : [ 16, 32 ]
                  }
               ],
               "name" : "jacket",
               "parent" : "body",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            }
         ],
         "description" : {
            "identifier" : "geometry.humanoid.custom",
            "texture_height" : 64,
            "texture_width" : 64,
            "visible_bounds_height" : 2,
            "visible_bounds_offset" : [ 0, 1, 0 ],
            "visible_bounds_width" : 1
         }
      },
      {
         "bones" : [
            {
               "name" : "root",
               "pivot" : [ 0.0, 0.0, 0.0 ]
            },
            {
               "name" : "waist",
               "parent" : "root",
               "pivot" : [ 0.0, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -4.0, 12.0, -2.0 ],
                     "size" : [ 8, 12, 4 ],
                     "uv" : [ 16, 16 ]
                  }
               ],
               "name" : "body",
               "parent" : "waist",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -4.0, 24.0, -4.0 ],
                     "size" : [ 8, 8, 8 ],
                     "uv" : [ 0, 0 ]
                  }
               ],
               "name" : "head",
               "parent" : "body",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.50,
                     "origin" : [ -4.0, 24.0, -4.0 ],
                     "size" : [ 8, 8, 8 ],
                     "uv" : [ 32, 0 ]
                  }
               ],
               "name" : "hat",
               "parent" : "head",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -3.90, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 16 ]
                  }
               ],
               "name" : "rightLeg",
               "parent" : "root",
               "pivot" : [ -1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -3.90, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 32 ]
                  }
               ],
               "name" : "rightPants",
               "parent" : "rightLeg",
               "pivot" : [ -1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -0.10, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 16, 48 ]
                  }
               ],
               "mirror" : true,
               "name" : "leftLeg",
               "parent" : "root",
               "pivot" : [ 1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -0.10, 0.0, -2.0 ],
                     "size" : [ 4, 12, 4 ],
                     "uv" : [ 0, 48 ]
                  }
               ],
               "name" : "leftPants",
               "parent" : "leftLeg",
               "pivot" : [ 1.90, 12.0, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ 4.0, 11.50, -2.0 ],
                     "size" : [ 3, 12, 4 ],
                     "uv" : [ 32, 48 ]
                  }
               ],
               "name" : "leftArm",
               "parent" : "body",
               "pivot" : [ 5.0, 21.50, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ 4.0, 11.50, -2.0 ],
                     "size" : [ 3, 12, 4 ],
                     "uv" : [ 48, 48 ]
                  }
               ],
               "name" : "leftSleeve",
               "parent" : "leftArm",
               "pivot" : [ 5.0, 21.50, 0.0 ]
            },
            {
               "name" : "leftItem",
               "parent" : "leftArm",
               "pivot" : [ 6, 14.50, 1 ]
            },
            {
               "cubes" : [
                  {
                     "origin" : [ -7.0, 11.50, -2.0 ],
                     "size" : [ 3, 12, 4 ],
                     "uv" : [ 40, 16 ]
                  }
               ],
               "name" : "rightArm",
               "parent" : "body",
               "pivot" : [ -5.0, 21.50, 0.0 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -7.0, 11.50, -2.0 ],
                     "size" : [ 3, 12, 4 ],
                     "uv" : [ 40, 32 ]
                  }
               ],
               "name" : "rightSleeve",
               "parent" : "rightArm",
               "pivot" : [ -5.0, 21.50, 0.0 ]
            },
            {
               "locators" : {
                  "lead_hold" : [ -6, 14.50, 1 ]
               },
               "name" : "rightItem",
               "parent" : "rightArm",
               "pivot" : [ -6, 14.50, 1 ]
            },
            {
               "cubes" : [
                  {
                     "inflate" : 0.250,
                     "origin" : [ -4.0, 12.0, -2.0 ],
                     "size" : [ 8, 12, 4 ],
                     "uv" : [ 16, 32 ]
                  }
               ],
               "name" : "jacket",
               "parent" : "body",
               "pivot" : [ 0.0, 24.0, 0.0 ]
            },
            {
               "name" : "cape",
               "parent" : "body",
               "pivot" : [ 0.0, 24, -3.0 ]
            }
         ],
         "description" : {
            "identifier" : "geometry.humanoid.customSlim",
            "texture_height" : 64,
            "texture_width" : 64,
            "visible_bounds_height" : 2,
            "visible_bounds_offset" : [ 0, 1, 0 ],
            "visible_bounds_width" : 1
         }
      }
   ]
}
`
