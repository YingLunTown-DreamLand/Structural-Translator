// Package text has utility methods used for formatting text to display in Minecraft, and to convert these
// colour codes into codes suitable for the command line.
package text
