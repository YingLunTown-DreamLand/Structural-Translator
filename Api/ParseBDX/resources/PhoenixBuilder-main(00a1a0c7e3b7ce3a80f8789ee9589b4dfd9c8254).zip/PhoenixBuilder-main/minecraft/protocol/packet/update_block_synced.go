package packet

import (
	"phoenixbuilder/minecraft/protocol"
)

const (
	BlockToEntityTransition = iota + 1
	EntityToBlockTransition
)

// UpdateBlockSynced is sent by the server to synchronise the falling of a falling block entity with the
// transitioning back and forth from and to a solid block. It is used to prevent the entity from flickering,
// and is used in places such as the pushing of blocks with pistons.
type UpdateBlockSynced struct {
	// Position is the block position at which a block is updated.
	Position protocol.BlockPos
	// NewBlockRuntimeID is the runtime ID of the block that is placed at Position after sending the packet
	// to the client.
	NewBlockRuntimeID uint32
	// Flags is a combination of flags that specify the way the block is updated client-side. It is a
	// combination of the flags above, but typically sending only the BlockUpdateNetwork flag is sufficient.
	Flags uint32
	// Layer is the world layer on which the block is updated. For most blocks, this is the first layer, as
	// that layer is the default layer to place blocks on, but for blocks inside of each other, this differs.
	Layer uint32
	// EntityUniqueID is the unique ID of the falling block entity that the block transitions to or that the
	// entity transitions from.
	// Note that for both possible values for TransitionType, the EntityUniqueID should point to the falling
	// block entity involved.
	EntityUniqueID int64
	// TransitionType is the type of the transition that happened. It is either BlockToEntityTransition, when
	// a block placed becomes a falling entity, or EntityToBlockTransition, when a falling entity hits the
	// ground and becomes a solid block again.
	TransitionType uint64
}

// ID ...
func (*UpdateBlockSynced) ID() uint32 {
	return IDUpdateBlockSynced
}

// Marshal ...
func (pk *UpdateBlockSynced) Marshal(w *protocol.Writer) {
	w.UBlockPos(&pk.Position)
	w.Varuint32(&pk.NewBlockRuntimeID)
	w.Varuint32(&pk.Flags)
	w.Varuint32(&pk.Layer)
	w.Varint64(&pk.EntityUniqueID)
	w.Varuint64(&pk.TransitionType)
}

// Unmarshal ...
func (pk *UpdateBlockSynced) Unmarshal(r *protocol.Reader) {
	r.UBlockPos(&pk.Position)
	r.Varuint32(&pk.NewBlockRuntimeID)
	r.Varuint32(&pk.Flags)
	r.Varuint32(&pk.Layer)
	r.Varint64(&pk.EntityUniqueID)
	r.Varuint64(&pk.TransitionType)
}
