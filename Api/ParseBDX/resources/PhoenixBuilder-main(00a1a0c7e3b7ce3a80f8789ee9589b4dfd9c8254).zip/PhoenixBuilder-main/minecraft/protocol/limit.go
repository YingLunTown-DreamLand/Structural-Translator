package protocol

const lowerLimit = 64
const mediumLimit = 256
const higherLimit = 1024
